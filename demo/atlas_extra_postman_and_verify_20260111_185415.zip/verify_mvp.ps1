Invoke-RestMethod http://localhost:8080/api/health

#!/usr/bin/env bash
curl -s http://localhost:8080/api/health

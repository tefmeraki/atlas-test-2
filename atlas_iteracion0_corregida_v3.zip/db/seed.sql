-- ATLAS Club (Iteración 0) - Datos de ejemplo mínimos
INSERT INTO club_member(full_name, email) VALUES
('Ana López', 'ana@example.com'),
('Bruno García', 'bruno@example.com');

INSERT INTO facility(name, facility_type) VALUES
('Pista 1', 'TENNIS'),
('Pista 2', 'TENNIS'),
('Sala Multiusos', 'INDOOR');

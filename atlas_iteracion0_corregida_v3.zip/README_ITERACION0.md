Entregables Iteración 0 (corregida): db/, backend/, frontend/

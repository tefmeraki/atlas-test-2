# Frontend (placeholder) — ATLAS Iteración 0

En la Fase 3 (Iteración 0) NO se implementa frontend real.
Este directorio existe solo para dejar preparada la estructura del repo.

En iteraciones posteriores, si se decide UI mínima:
- puede ser una página estática muy simple o
- se puede mantener solo Swagger / Postman para demo.

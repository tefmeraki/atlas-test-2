package com.atlas.club;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtlasClubApplication {
    public static void main(String[] args) {
        SpringApplication.run(AtlasClubApplication.class, args);
    }
}
